import Mint from "./Mint";

import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'



function Minting() {
  const [accounts, setAccounts] = useState([]);

  return (
    <div className="App">
      <Mint  accounts={accounts} setAccounts={setAccounts}/> 
    </div>
  );
}

export default Minting;