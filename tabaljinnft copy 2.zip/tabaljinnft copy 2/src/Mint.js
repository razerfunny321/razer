import { useState } from 'react';
import { ethers, BigNumber} from 'ethers';
import TabalJinNFT from './TabalJinNFT.json';
import "./App.css";
import nft from "./assets/mawi.jpeg";

import 'bootstrap/dist/css/bootstrap.min.css';

const TabalJinAddress = "0x4606B775D2F09b09bd227EDE70A5333570c33E05"

const Mint  =({ accounts, setAccounts})=>{
    const [mintAmount, setMintAmounts] = useState(1);
    const isConnected = Boolean(accounts[0])

   async function handleMint() {
        if(window.ethereum){
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            const contract = new ethers.Contract(
                TabalJinAddress,
                TabalJinNFT.abi,
                signer
            );
            try{
                const response = await contract.mint(BigNumber.from(mintAmount), {
                    value: ethers.utils.parseEther((0.002 * mintAmount).toString()),
                });
                console.log('response: ', response);
            } catch(err){
                console.log("error: ", err)
            }   
        }
    }

    const handleDecrement = () =>{
        if (mintAmount <= 1) return;
        setMintAmounts(mintAmount-1);
    };

    const handleIncrement = () =>{
        if (mintAmount >= 3) return;
        setMintAmounts(mintAmount+1);
    };



return(
    <div class="bg3">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" ></script>
    <script src="https://kit.fontawesome.com/79d3e7fd5c.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css"></link>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"></link>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"></link>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"></link>

        <div class="card mt-4 rounded-3">
            <div class="row">
                <div class="col-md-8 cart">
                    <div>
                        <div class="row">
                            <div class="card-body text-center">
                                <img src={nft} class="img-fluid rounded-5" alt="..."/>
                            </div>
                        </div>
                    </div>
                </div> 

                <div class="col-md-4 summary text-center">
                    <div style={{fontFamily: 'Chalkduster'}}><h5><b>Tabal Jin NFT</b></h5></div>
                    <hr/>
                    <br/>
                    <div class="row text-center">
                        <div class="col float-left" style={{paddingLeft:0, fontFamily: 'Chalkduster'}}>BALANCE</div>
                        <div class="col text-right" style={{fontFamily: 'Chalkduster'}}> 200/1000</div>
                    </div>
                    <br/>
                    <hr/>
                    <form>
                        <p class="text-center" style={{fontFamily: 'Chalkduster'}}>CHOOSE YOUR AMOUNT</p>
                        <div class="input-group justify-content-center align-items-center mt-3 d-flex text-center">
                            <span class="input-group-btn">
                             <button type="button" class="btn btn-danger btn-number p-2 m-1 rounded-left" data-type="minus" data-field="quant[2]" onClick={handleDecrement}>
                            <i class="fa fa-minus"></i>
                            </button>
                            </span>
                            <input type="text" name="quant[2]" class="form-control input-number rounded m-2 w-50" value={mintAmount} min="1" max="100"/>
                            <span class="input-group-btn">
                            <button type="button" class="btn btn-success btn-number p-2 m-1 rounded-right" data-type="plus" data-field="quant[2]" onClick={handleIncrement}>
                             <i class="fa fa-plus"></i>
                            </button>
                            </span>
                            <br/>
                            <br/>
                            <label for=""><i class="fab fa-ethereum"></i> ETH Price : 0.1 Per NFT </label>
                        </div>
                    </form>
                        <hr/>
                        <div class="pt-3 ml-5">
                            <div class="rgb-border align-content-center rounded">
                                <a class="butang rounded" href="#" style={{fontFamily: 'Chalkduster'}} onClick={handleMint}>MINT</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                

    )
};

export default Mint;