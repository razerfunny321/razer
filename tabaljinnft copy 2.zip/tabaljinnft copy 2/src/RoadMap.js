import React from "react";
import "./App.css";

import 'bootstrap/dist/css/bootstrap.min.css';

const RoadMap  =({ accounts, setAccounts})=>{
    return(
        <div id="RoadMap" class="bg2">
            <section id="roadmap">
        <div class="bg2">
            <div class="container pt-5">
                <center>
            <h1 class="title1 text-center">Tabal Jin RoadMap</h1>
            </center>
                <div class="main-timeline">
                    
                                        {/* <!-- start experience section--> */}
                                        <div class="timeline">
                                    
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">MARCH</span>
                                                    <span class="year">2022</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                Film Development
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">APRIL</span>
                                                    <span class="year">2022</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                NFT Project Kick-Off 
                                                <br/>
                                                Private Sale 100NFT
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">MAY</span>
                                                    <span class="year">2022</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                Shooting Starts
                                                <br/>
                                                NFT Education Campaign (Public)
                                                <br/>
                                                Private Sale 500NFT
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">JUNE</span>
                                                    <span class="year">2022</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                NFT Education Campaign (Artists)
                                                <br/>
                                                Private Sale 500NFT
                                                <br/>
                                                Promotion Campaign
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                                        
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">JULY</span>
                                                    <span class="year">2022</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                NFT Launching With Minister
                                                <br/>
                                                Film Post Production
                                                <br/>
                                                Public Sale 900NFT
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">AUGUST</span>
                                                    <span class="year">2022</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                
                                                <p class="description">
                                                Get-Together Event NFT Holders & Artists
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">NOVEMBER</span>
                                                    <span class="year">2022</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                TABAL JIN Astro First Release
                                                <br/>
                                                Film Premiere With NFT Holders
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">APRIL</span>
                                                    <span class="year">2023</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                20% Royalty Distribution To NFT Holders
                                                <br/>
                                                Get-Together Event NFT Holders & Artists
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section-->
                                        <!-- start experience section--> */}
                                        <div class="timeline">
                                            <div class="icon"></div>
                                            <div class="date-content">
                                                <div class="date-outer">
                                                    <span class="date">
                                                            <span class="month">MAY</span>
                                                    <span class="year">2023</span>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="timeline-content">
                                                <p class="description">
                                                TABAL JIN 2 Shooting Starts
                                                </p>
                                            </div>
                                        </div>
                                        {/* <!-- end experience section--> */}
                                    </div>
                </div>
    </div>
    </section> 
            
        </div>
    )
};

export default RoadMap;