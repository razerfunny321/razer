import RoadMap from "./RoadMap";
import MainMint from "./MainMint";


import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'



function Home() {
  const [accounts, setAccounts] = useState([]);

  return (
    <div className="App">
      <MainMint  accounts={accounts} setAccounts={setAccounts}/> 
      <RoadMap accounts={accounts} setAccounts={setAccounts}/> 
    </div>
  );
}

export default Home;