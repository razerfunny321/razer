import NavBar from "./Navbar";
import Home from "./Home";
import Minting from "./Minting";

import './App.css';

import {Routes, Route } from 'react-router-dom'
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'



function App() {
  const [accounts, setAccounts] = useState([]);
  return (
    <div className="App">
      <NavBar  accounts={accounts} setAccounts={setAccounts}/> 

      <Routes>
         <Route path="/" element={<Home />} />
         <Route path="/Minting" element={<Minting />} />
      </Routes>   
    </div>
  );
}

export default App;
