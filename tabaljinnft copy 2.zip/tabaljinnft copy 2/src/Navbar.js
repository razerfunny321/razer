import React from "react";
import { Link } from "react-router-dom";

import "./App.css";
import {Button, Form, Navbar, Nav, Container, NavDropdown, FormControl} from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css'

const NavBar =({ accounts, setAccounts})=>{
  const isConnected = Boolean(accounts[0]);

  async function connectAccount(){
      if(window.ethereum){
          const account = await window.ethereum.request({
              method: "eth_requestAccounts",

          });
          
          setAccounts(account);
      }
  }

  function isMobileDevice() {
    return 'ontouchstart' in window || 'onmsgesturechange' in window;
  }

  if (isMobileDevice()) {
    const dappUrl = "nft.maishince.academy";
    const metamaskAppDeepLink = "https://metamask.app.link/dapp/" + dappUrl;

    return(
      <div>
  <link rel="icon" href="icon.jpeg"></link>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" ></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" ></script>
  <script src="https://kit.fontawesome.com/79d3e7fd5c.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css"></link>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"></link>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"></link>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"></link>


  <Navbar bg="light" expand="lg">
<Container fluid>
  <Navbar.Brand href="/" class="navbar navbar-expand-lg navbar-light navbar-brand ml-4 text-white bg-black rounded pt-2 pb-2" id="brand" >Tabal Jin</Navbar.Brand>
  <Nav className=" my-2 my-lg-0" style={{ maxHeight: '150px', width: '20%', marginRight:'0px'}}>
        <Nav.Link className="pl-1" id="navbarNav" href="/#roadmap" style={{float:'left'}}>Road Map</Nav.Link>
    </Nav>
    <Nav className=" my-2 my-lg-0" style={{ maxHeight: '150px', width: '20%', marginRight:'0px'}}>
        <Nav.Link className="pl-1" id="navbarNav" href="#" style={{float:'left'}}><Link to="/Minting" className="pl-1" id="navbarNav" style={{color:'rgba(0,0,0,.5)'}}>Mint</Link></Nav.Link>
    </Nav>
      <Nav style={{float:'right', maxHeight: '150px', width: '20%', marginRight:'0px'}}>
        {isConnected ?(
        <Nav.Link className="pl-0" id="navbarNav" href="#action3">Connected</Nav.Link>
        ):(
          <Nav.Link className="pl-0" id="navbarNav" href="#action3">Connect</Nav.Link>
        )}
      
      </Nav>
</Container>
</Navbar>

      </div>

  )
}


    return(
        <div>
    <link rel="icon" href="icon.jpeg"></link>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" ></script>
    <script src="https://kit.fontawesome.com/79d3e7fd5c.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css"></link>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"></link>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"></link>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"></link>


    <Navbar bg="light" expand="lg">
    <Container fluid>
  <Navbar.Brand href="/" class="navbar navbar-expand-lg navbar-light navbar-brand ml-4 text-white bg-black rounded pt-2 pb-2" id="brand" >Tabal Jin</Navbar.Brand>
  <Nav className=" my-2 my-lg-0" style={{ maxHeight: '150px', width: '20%', marginRight:'0px'}}>
        <Nav.Link className="pl-1" id="navbarNav" href="/#roadmap" style={{float:'left'}}>Road Map</Nav.Link>
    </Nav>
    <Nav className=" my-2 my-lg-0" style={{ maxHeight: '150px', width: '20%', marginRight:'0px'}}>
        <Nav.Link className="pl-1" id="navbarNav" href="#" style={{float:'left'}}><Link to="/Minting" className="pl-1" id="navbarNav" style={{color:'rgba(0,0,0,.5)'}}>Mint</Link></Nav.Link>
    </Nav>
      <Nav style={{float:'right', maxHeight: '150px', width: '20%', marginRight:'0px'}}>
        {isConnected ?(
        <Nav.Link className="pl-0" id="navbarNav" href="#action3">Connected</Nav.Link>
        ):(
          <Nav.Link className="pl-0" id="navbarNav" href="#action3" disabled>Connect</Nav.Link>
        )}
      
      </Nav>
</Container>
</Navbar>


        </div>

    )
};

export default NavBar;