const hre = require("hardhat");

async function main() {

  const TabalJinNFT = await hre.ethers.getContractFactory("TabalJinNFT");
  const tabalJinNFT = await TabalJinNFT.deploy();

  await tabalJinNFT.deployed();

  console.log("TabalJinNFT deployed to:", tabalJinNFT.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
