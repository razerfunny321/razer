import React from "react";
import "./App.css";
import { Container } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';

const MainMint  =({ accounts, setAccounts})=>{
    const isConnected = Boolean(accounts[0]);
    async function connectAccount(){
        if(window.ethereum){
            const account = await window.ethereum.request({
                method: "eth_requestAccounts",
  
            });
            
            setAccounts(account);
        }
    }

    function isMobileDevice() {
        return 'ontouchstart' in window || 'onmsgesturechange' in window;
      }
    
      if (isMobileDevice()) {
        const dappUrl = "nft.maishince.academy"; 
        const metamaskAppDeepLink = "https://metamask.app.link/dapp/" + dappUrl;
    
        return(
        <div id="MainMint" class="bg">
        <Container>

        {isConnected ?(
        <>
        <h1 class="dis1 display-3 justify-content-center align-items-center mt-5 d-flex">TABAL JIN</h1>
        <h3 class="dis2 display-5 justify-content-center align-items-center mt-3 d-flex" >NFT PAGE</h3>
        <div class="justify-content-center align-items-center mt-5 d-flex">
            <button type="button" class="btn btn-outline-success round btn-min-width mr-1 mb-1 pt-2 pb-2 pl-4 pr-4 shadow-lg p-3 mb-5">YOU ARE ALL SET <i class="fab fa-ethereum"></i> </button>
        </div>
        </>
        ):(
        <>
        <h1 class="dis1 display-3 justify-content-center align-items-center mt-5 d-flex">TABAL JIN</h1>
        <h3 class="dis2 display-5 justify-content-center align-items-center mt-3 d-flex" >NFT PAGE</h3>
        <div class="justify-content-center align-items-center mt-5 d-flex">
        <a href={metamaskAppDeepLink}><button type="button" class="btn btn-outline-success round btn-min-width mr-1 mb-1 pt-2 pb-2 pl-4 pr-4 shadow-lg p-3 mb-5" onClick={connectAccount}> CONNECT WITH ETHEREUM NOW <i class="fab fa-ethereum"></i></button></a>
         </div>
         </>
        )}
         
        </Container>
    </div>

        )
     }
    return(
    <div id="MainMint" class="bg">
        <Container>
        {isConnected ?(
        <>
        <h1 class="dis1 display-3 justify-content-center align-items-center mt-5 d-flex">TABAL JIN</h1>
        <h3 class="dis2 display-5 justify-content-center align-items-center mt-3 d-flex" >NFT PAGE</h3>
        <div class="justify-content-center align-items-center mt-5 d-flex">
            <button type="button" class="btn btn-outline-success round btn-min-width mr-1 mb-1 pt-2 pb-2 pl-4 pr-4 shadow-lg p-3 mb-5">YOU ARE ALL SET <i class="fab fa-ethereum"></i> </button>
        </div>
        </>
        ):(
        <>
        <h1 class="dis1 display-3 justify-content-center align-items-center mt-5 d-flex">TABAL JIN</h1>
        <h3 class="dis2 display-5 justify-content-center align-items-center mt-3 d-flex" >NFT PAGE</h3>
        <div class="justify-content-center align-items-center mt-5 d-flex">
            <button type="button" class="btn btn-outline-success round btn-min-width mr-1 mb-1 pt-2 pb-2 pl-4 pr-4 shadow-lg p-3 mb-5" onClick={connectAccount}> CONNECT WITH ETHEREUM NOW <i class="fab fa-ethereum"></i> </button>
         </div>
         </>
        )}
        
        </Container>
    </div>
    )
};

export default MainMint;